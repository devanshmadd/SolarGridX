//
//  ExploreTableViewCell.swift
//  SolarGridX
//
//  Created by Devansh Shah on 27/01/2020.
//  Copyright © 2020 Devansh Shah. All rights reserved.
//

import UIKit

protocol ExploreCellDelegate {
    func didTapReadMore(title: String)
    func didTapShare(title: String)
}
class ExploreTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var myLabel: UILabel!
    
    var delegate: ExploreCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func readMoreTapped(_ sender: Any) {
        delegate?.didTapReadMore(title: myLabel.text!)
    }
    @IBAction func shareTapped(_ sender: Any) {
        delegate?.didTapShare(title: myLabel.text!)
        
        
    }
    
    
}
