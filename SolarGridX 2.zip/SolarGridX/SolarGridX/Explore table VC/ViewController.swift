//
//  ViewController.swift
//  SolarGridX
//
//  Created by Devansh Shah on 27/01/2020.
//  Copyright © 2020 Devansh Shah. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let explore = ["High School | 90.45kW | New Delhi, India", "Fergusson College | 64.68kW | Mumbai, India", "Spar Supermarket | 65.30kW | Melbourne, Australia", "Farmhouse No.13 | 42.88kW | Gladstone, Australia", "Clothing Factory | 84.70kW | Gurgaon, Haryana", "Resort | 94.40kW | Hyderabad, India", "Golf Links Residential Apartments | 73.26kW | Ahmedabad, India"]
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return (explore.count)
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ExploreTableViewCell
        
        cell.myImage.image = UIImage(named: (explore[indexPath.row] + ".jpg"))
        cell.myLabel.text = explore[indexPath.row]
        cell.delegate = self
        
        return (cell)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController : ExploreCellDelegate {
    
    func didTapReadMore(title: String) {
        let alertTtile = "Shortlisted tab coming soon"
        let message = "Item will be added to the Shortlist."
        
        let alert = UIAlertController(title: alertTtile, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok, cool!", style: .default, handler: nil))
        present(alert,animated: true,completion: nil)

    }
    
    func didTapShare(title: String) {
        let activityVC = UIActivityViewController(activityItems: ["\(String(describing: mymsg.self))"], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        
        self.present(activityVC, animated: true, completion: nil)    }
}


