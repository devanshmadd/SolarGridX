//
//  AuthenticationViewController.swift
//  SolarGridX
//
//  Created by Devansh Shah on 28/01/2020.
//  Copyright © 2020 Devansh Shah. All rights reserved.
//

import LocalAuthentication
import UIKit
import Firebase
import FirebaseAuth

class AuthenticationiewController: UIViewController {
    
    @IBOutlet weak var loginButton: UIButton!
    
    @IBOutlet weak var logout: RoundedWhiteButton!
    @IBOutlet weak var signupButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Add the background gradient
   //     view.addVerticalGradientLayer(topColor: primaryColor, bottomColor: secondaryColor)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {


                  if !isLoggedIn{
                      logout.isEnabled = false
                      logout.tintColor = UIColor.clear
                  }else{
                      logout.isEnabled = true
                      logout.tintColor = UIColor.white
                    loginButton.isEnabled = true
                    loginButton.tintColor = UIColor.clear
                    signupButton.isEnabled = true
                    signupButton.tintColor = UIColor.clear
                }
           
        
//        let context = LAContext()
//                                        var error: NSError?
//
//                                        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
//                                            let reason = "Identify yourself!"
//
//                                            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
//                                                [weak self] success, authenticationError in
//
//                                                DispatchQueue.main.async {
//                                                    if success {
//                                                     self?.performSegue(withIdentifier: "success", sender: self)                                               } else {
//                                                         let ac = UIAlertController(title: "Authentication failed", message: "You could not be verified; please try again.", preferredStyle: .alert)
//                                                        ac.addAction(UIAlertAction(title: "OK", style: .default))
//                                                        self?.present(ac, animated: true)
//                                                    }
//                                                }
//                                            }
//                                        } else {
//                                            let ac = UIAlertController(title: "Biometric unavailable", message: "Your device is not configured for biometric authentication.", preferredStyle: .alert)
//                                            ac.addAction(UIAlertAction(title: "OK", style: .default))
//                                            self.present(ac, animated: true)
//                                        }
//
//
//
//
//    }
        
        super.viewWillAppear(animated)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
//        if Auth.auth().currentUser != nil {
//            self.performSegue(withIdentifier: "toHomeScreen", sender: self)
//        }
  }
    @IBAction func logoutAction(_ sender: Any) {
        
        isLoggedIn.self = false
        logout.isEnabled = false
        logout.tintColor = UIColor.clear
        loginButton.isEnabled = true
        loginButton.tintColor = UIColor.white
        signupButton.isEnabled = true
        signupButton.tintColor = UIColor.white
        
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        get {
            return .lightContent
        }
    }
    
    
  @IBAction func authtap(_ sender: Any) {
////                let context = LAContext()
////                                                var error: NSError?
////
////                                                if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
////                                                    let reason = "Identify yourself!"
////
////                                                    context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
////                                                        [weak self] success, authenticationError in
////
////                                                        DispatchQueue.main.async {
////                                                            if success {
////                                                                self?.performSegue(withIdentifier: "success", sender: self)                                          } else {
////                                                                 let ac = UIAlertController(title: "Authentication failed", message: "You could not be verified; please try again.", preferredStyle: .alert)
////                                                                ac.addAction(UIAlertAction(title: "OK", style: .default))
////                                                                self?.present(ac, animated: true)
////                                                            }
////                                                        }
////                                                    }
////                                                } else {
////                                                    let ac = UIAlertController(title: "Biometric unavailable", message: "Your device is not configured for biometric authentication.", preferredStyle: .alert)
////                                                    ac.addAction(UIAlertAction(title: "OK", style: .default))
////                                                    self.present(ac, animated: true)
////                                                }
////
//
        
        
        
   }
    
    
    
}
