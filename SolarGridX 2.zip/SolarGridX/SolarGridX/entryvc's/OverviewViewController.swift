//
//  OverviewViewController.swift
//  SolarGridX
//
//  Created by Devansh Shah on 30/01/2020.
//  Copyright © 2020 Devansh Shah. All rights reserved.
//

import LocalAuthentication
import UIKit
import Firebase
import MessageUI


class OverviewViewController: UIViewController, MFMailComposeViewControllerDelegate {

    @IBOutlet weak var buySell: UIBarButtonItem!
    override func viewDidLoad() {
//        super.viewDidLoad()
        
        let context = LAContext()
                                                      var error: NSError?
              
                                                      if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
                                                          let reason = "Identify yourself!"
              
                                                          context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
                                                              [weak self] success, authenticationError in
              
                                                              DispatchQueue.main.async {
                                                                  if success {
                                                                      self?.navigationController?.popToRootViewController(animated: true)                                        } else {
                                                                       let ac = UIAlertController(title: "Authentication failed", message: "You could not be verified; please try again.", preferredStyle: .alert)
                                                                      ac.addAction(UIAlertAction(title: "OK", style: .default))
                                                                      self?.present(ac, animated: true)
                                                                  }
                                                              }
                                                          }
                                                      } else {
                                                          let ac = UIAlertController(title: "Biometric unavailable", message: "Your device is not configured for biometric authentication.", preferredStyle: .alert)
                                                          ac.addAction(UIAlertAction(title: "OK", style: .default))
                                                          self.present(ac, animated: true)
                                                      }
              

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var SGXtokens: UILabel!
    @IBOutlet weak var AEDamt: UILabel!
    
    @IBOutlet weak var earnings: UILabel!
    override func viewWillAppear(_ animated: Bool) {
        
        UINavigationBar.appearance().barTintColor = UIColor.systemOrange

        // Or, Set to new colour for just this navigation bar
        self.navigationController?.navigationBar.barTintColor = UIColor.systemOrange
           

           if !isLoggedIn{
               buySell.isEnabled = false
               buySell.tintColor = UIColor.clear
           }else{
               buySell.isEnabled = true
               buySell.tintColor = UIColor.black
           }
        
        SGXtokens.text = "\(bought) SGX Tokens"
        AEDamt.text = "\(aed) AED left"
        earnings.text = "\(sell2)"
        
       
       }
    
    func showAlert2(title: String, message: String){
           let alert = UIAlertController(title: title , message: message, preferredStyle: .alert)
           
           let alertCancel = UIAlertAction(title: "Okay.", style: .cancel, handler: nil)
           
           alert.addAction(alertCancel)
           self.present(alert, animated: true)
       }
     
    
    @IBAction func TinTapped(_ sender: Any) {
         showAlert2(title: "This is a mock amount for your demo account", message: "You cannot transfer it in right now.")
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        //Revert to old colour, whole app
        UINavigationBar.appearance().barTintColor = UIColor.systemOrange

        //Revert to old colour, just this navigation bar
        self.navigationController?.navigationBar.barTintColor = UIColor.systemOrange
    }
    
    
    @IBAction func Touttapped(_ sender: Any) {
        
         showAlert2(title: "This is a mock amount for your demo account", message: "You cannot transfer it out right now.")
        
    }
    
    @IBAction func depositAED(_ sender: Any) {
          showAlert2(title: "This is your mock account", message: "You cannot deposit any money as of now.")
        
    }
    
    @IBAction func withdrawal(_ sender: Any) {
         showAlert2(title: "This is your mock account", message: "You cannot withdraw any money as of now.")
        
    }
    
    @IBAction func support(_ sender: Any) {
           let mailComposeViewController = configureMailController()
             if MFMailComposeViewController.canSendMail() {
                 self.present(mailComposeViewController, animated: true, completion: nil)
             } else {
                 showMailError()
             }
         }
         
         func configureMailController() -> MFMailComposeViewController {
             let mailComposerVC = MFMailComposeViewController()
             mailComposerVC.mailComposeDelegate = self
             
             mailComposerVC.setToRecipients(["founders@solargridx.org"])
             mailComposerVC.setSubject("Need some help on it.")
             mailComposerVC.setMessageBody("Need help regarding the following app.", isHTML: false)
             
             return mailComposerVC
         }
         
         func showMailError() {
             let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email", preferredStyle: .alert)
             let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
             sendMailErrorAlert.addAction(dismiss)
             self.present(sendMailErrorAlert, animated: true, completion: nil)
         }
         
         func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
             controller.dismiss(animated: true, completion: nil)
         }
    
    
    @IBAction func feedback(_ sender: Any) {
        
        let mailComposeViewController = configureMailController2()
                   if MFMailComposeViewController.canSendMail() {
                       self.present(mailComposeViewController, animated: true, completion: nil)
                   } else {
                       showMailError()
                   }
        
        
    }
    
    func configureMailController2() -> MFMailComposeViewController {
              let mailComposerVC = MFMailComposeViewController()
              mailComposerVC.mailComposeDelegate = self
              
              mailComposerVC.setToRecipients(["founders@solargridx.org"])
              mailComposerVC.setSubject("Need to provide feedback")
              mailComposerVC.setMessageBody("About your app, we need to provide you with feedback.", isHTML: false)
              
              return mailComposerVC
          }
    
}



    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


