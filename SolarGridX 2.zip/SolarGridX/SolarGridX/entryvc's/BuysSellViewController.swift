//
//  BuysSellViewController.swift
//  SolarGridX
//
//  Created by Devansh Shah on 31/01/2020.
//  Copyright © 2020 Devansh Shah. All rights reserved.
//

import UIKit
import Firebase


var bought: Int = 0
var aed: Int = 1000
var sell2: Int = 1000
var count1: Int = 0
var count2: Int = 0

class BuysSellViewController: UIViewController {

    @IBOutlet weak var amtSGX: UITextField!
    @IBOutlet weak var sellamtSGX: UITextField!
    
    @IBOutlet weak var priceSGX: UITextField!
    @IBOutlet weak var sellPriceSGX: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        amtSGX.delegate = self
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")

           //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
           //tap.cancelsTouchesInView = false

           view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view.
    }
    
   

      @objc func dismissKeyboard() {
          view.endEditing(true)
      }
    
    
    @IBAction func priceTapped(_ sender: Any) {
       
        priceSGX.text = "\((Int(amtSGX.text!) ?? 0) * 35)"
        count1 = ((Int(amtSGX.text!) ?? 0) * 35)
    }
    
    func showAlert2(title: String, message: String){
                  let alert = UIAlertController(title: title , message: message, preferredStyle: .alert)
                  
                  let alertCancel = UIAlertAction(title: "Okay, thanks.", style: .cancel, handler: nil)
                  
                  alert.addAction(alertCancel)
                  self.present(alert, animated: true)
              }
           
    
    @IBAction func buyTapped(_ sender: Any) {
       
        bought  = bought + (Int(amtSGX.text!) ?? 0)
        aed = aed - (Int(count1))
          showAlert2(title: "Mock SGX tokens added to your SGX Trading axccount", message: "And the AED amount has been deducted from your AED Account.")
        
        let newbuy =   Database.database().reference().child("user").childByAutoId()
                       
        let buydata = ["SGXBought": "\(amtSGX.text ?? "00")"]
                       
                               newbuy.setValue(buydata)
       
        
        
    }
    
    @IBAction func sellPriceTapped(_ sender: Any) {
        sellPriceSGX.text = "\((Int(sellamtSGX.text!) ?? 0) * 35) "
        count2 = ((Int(sellamtSGX.text!) ?? 0) * 35)
    }
    
    @IBAction func SellTapped(_ sender: Any) {
        bought = bought - (Int(sellamtSGX.text!) ?? 0)
        aed = aed + (Int(count2))
        sell2 = aed + (Int(count2))
        
          showAlert2(title: "Mock SGX tokens deducted from your SGX Trading axccount", message: "And the AED amount has been added to your AED Account.")
        
        let newSell =   Database.database().reference().child("user").childByAutoId()
                              
               let selldata = ["SGXSold": "\(sellamtSGX.text ?? "00")"]
                              
                                      newSell.setValue(selldata)
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
              amtSGX.resignFirstResponder()
          }
        
    }




extension BuysSellViewController : UITextFieldDelegate {
       
       func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           textField.resignFirstResponder()
           return true
       }
   }
