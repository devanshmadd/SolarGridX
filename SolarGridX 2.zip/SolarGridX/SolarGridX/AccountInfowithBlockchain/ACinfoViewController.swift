//
//  ACinfoViewController.swift
//  SolarGridX
//
//  Created by Devansh Shah on 31/01/2020.
//  Copyright © 2020 Devansh Shah. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import SwiftyJSON
import SafariServices



class ACinfoViewController: UIViewController {
    
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var transaction: UILabel!
    @IBOutlet weak var linkButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

            
        }
    

    override func viewWillAppear(_ animated: Bool) {
              

              if !isLoggedIn{
                  email.isEnabled = false
                  email.tintColor = UIColor.black
                  address.isEnabled = false
                  address.tintColor = UIColor.black
                  transaction.isEnabled = false
                  transaction.tintColor = UIColor.black
                linkButton.isEnabled = false
                linkButton.tintColor = UIColor.black
              }else{
                  email.isEnabled = true
                  email.text = "\(val)"
                  email.textColor = UIColor.white
                  address.isEnabled = true
                  address.textColor = UIColor.white
                  transaction.isEnabled = true
                  transaction.textColor = UIColor.white
                linkButton.isEnabled = true
              
                    Database.database().reference().child("user").observe(.childAdded) { (snapshot) in

                                   let json = JSON(snapshot.value!)
                  
                 self.address.text = json["wallet"].stringValue
                 self.transaction.text = json["tran"].stringValue
                        
                        self.linkButton.setTitle("View my transactions", for: .normal)
     

          }
        

}
}
    @IBAction func btnPressed(_ sender: Any) {
        
        
        Database.database().reference().child("user").observe(.childAdded) { (snapshot) in

                         let json = JSON(snapshot.value!)
        
           
             guard let url = URL(string: "\(json["tran"].string ?? "www.google.com")") else {
                 return
             }
    
            
            let safariVC = SFSafariViewController(url: url)
                safariVC.delegate = self
            self.present(safariVC, animated: true, completion: nil)
            }
            
        
    }
    
}



extension ACinfoViewController: SFSafariViewControllerDelegate{
    func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        controller.dismiss(animated: true, completion: nil)
    }
}
